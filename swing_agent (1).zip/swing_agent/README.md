# Swing trading-agent (paper trading, backtest)

Trend/momentum swing-strategi med 3 måneders rebalanceringscyklus. Bygget til
at teste idéen på historiske data, FØR der overvejes noget som helst med
rigtige penge på Nordnet.

**Status: kun backtest på historiske data. Ingen live-handel, ingen
Nordnet-integration, ingen automatisk ordreafgivelse.** Nordnet har ikke en
åben, offentlig handels-API, så det er bevidst ikke en del af dette projekt.

## Hvorfor kører du det selv?

Sandboxen denne agent blev bygget i har kun netadgang til pakke-registre
(pypi/npm/github) — ikke til kursdata-udbydere som Yahoo Finance. Koden er
derfor testet med syntetisk (falsk) data for at verificere at den kører uden
fejl, men ALDRIG kørt på rigtige kurser. Projektet er desuden bevidst holdt
let (kun `yfinance` + `pandas` + `numpy` — ingen `pyarrow`, ingen
`matplotlib`; graferne er håndbyggede SVG'er i ren Python) netop for at gøre
det realistisk at køre på en telefon, ikke kun en pc.

**Jeg har ikke selv kunnet teste dette på iOS** — jeg har ikke adgang til en
iPhone herfra. Nedenstående er mit bedste bud; hvis noget fejler, så send mig
fejlbeskeden, så retter vi til sammen.

## Kør fra iPhone

Der findes ikke et "terminal-look-and-feel" som Termux (Android) til iOS —
Apple tillader det ikke på samme måde. Jeg har undersøgt dette grundigt
(inkl. slået pakkeafhængigheder op direkte på PyPI) og anbefaler nu i denne
rækkefølge:

| Løsning | Pris | Vurdering |
|---|---|---|
| **Google Colab** (i Safari) | Gratis | **Anbefalet førstevalg.** Kører i skyen, ikke på telefonen — så INGEN installationsproblemer overhovedet. numpy/pandas indbygget, `pip install` virker altid (rigtig Linux-maskine bag kulissen). Tilgængelig fra enhver browser; kan lægges som ikon på hjemmeskærmen ("Føj til hjemmeskærm" i Safari). Kræver en Google-konto. |
| **a-Shell** | Gratis | Godt gratis on-device alternativ, hvis du hellere vil have det kørende lokalt/offline. Python 3.13, numpy/pandas/scipy er prebuilt til iOS. `pip` virker KUN til rene Python-pakker — se pin-anbefaling nedenfor. |
| **Pyto** | Betalt (~15 USD, engangskøb) | Kun relevant hvis de to gratis muligheder driller. Bemærk: jeg kan IKKE bekræfte at Pytos bundlede pakker inkluderer `curl_cffi` — betaling løser altså ikke nødvendigvis samme problem som a-Shell har. |

**Om `yfinance`-versionen — vigtigt, nu verificeret konkret:** Jeg har slået
op direkte i yfinance's afhængigheder på PyPI. Alle versioner fra og med
`0.2.58` kræver `curl_cffi` (kompileret Rust/C-pakke — vil sandsynligvis
FEJLE at installere on-device på iOS). Versionerne `0.2.54`–`0.2.56` kræver
derimod KUN rene Python-pakker (ingen `curl_cffi`, ingen `lxml`) — det er
derfor `requirements.txt` pinner `yfinance==0.2.55`. Ulempen ved den ældre
version er at den er lidt mere udsat for Yahoos anti-bot-blokering end
nyeste version — for en kvartalsvis kørsel af ~80 tickere bør det være en
fin afvejning.

**Fremgangsmåde — Google Colab (anbefalet):**

1. Åbn [colab.research.google.com](https://colab.research.google.com) i
   Safari på telefonen og log ind med en Google-konto.
2. Opret en ny notebook, upload `swing_agent`-mappens filer (eller kopiér
   dem ind som celler) — nemmest: upload som en zip og pak ud med
   `!unzip swing_agent.zip` i en celle.
3. Kør i celler:
   ```
   !pip install -r swing_agent/requirements.txt
   %cd swing_agent
   !python data_fetch.py --check
   !python run_backtest.py
   ```
4. Download eller åbn `output/report.html` direkte fra Colabs filpanel
   (tryk-og-hold → download, eller åbn i ny fane).
5. Læg evt. et Safari-ikon til Colab-notebooken på hjemmeskærmen, så det
   føles som en app.

**Fremgangsmåde — a-Shell (gratis, on-device):**

1. Overfør hele `swing_agent`-mappen til telefonen via iCloud Drive/Filer-
   appen (a-Shell kan køre scripts direkte fra Filer).
2. Åbn a-Shell og installér afhængigheder:
   ```
   pip install -r requirements.txt
   ```
3. Kør miljøtjekket FØR du prøver hele universet:
   ```
   python data_fetch.py --check
   ```
   Den henter kun 5 dages data for én aktie (AAPL) og fortæller om
   opsætningen virker.
4. Virker tjekket, kør den fulde backtest:
   ```
   python run_backtest.py
   ```
5. Åbn `output/report.html` — tryk på filen og vælg "Åbn i Safari", eller
   del den til Filer-appen.

**Hvis `pip install` alligevel fejler** (uanset app): send mig den præcise
fejlbesked — den navngiver altid den pakke der driller, og vi finder en
løsning (fx endnu en version-pin, eller at flytte kun datahentningen til
Colab og synke `cache/`-CSV'erne til telefonen bagefter).

## Kom i gang (pc/Mac, til reference)

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python run_backtest.py
```

Første kørsel henter ~80 tickeres historik via yfinance og cacher dem i
`cache/` som CSV-filer (kan tage et par minutter). Efterfølgende kørsler
bruger cachen — brug `python run_backtest.py --force` for at hente frisk
data.

Resultatet er `output/report.html` — åbn den i en browser.

## Hvad strategien gør

1. **Univers** (`universe.py`): ~80 likvide large/mid-cap aktier fordelt på
   US, Europa, Norden og emerging markets. Ret listen til hvis du vil handle
   et andet sæt aktier.
2. **Hver ~63 handelsdage (1 kvartal)** (`strategy.py`, `backtest.py`):
   - Trendfilter: aktien skal handle over sit 200-dages glidende gennemsnit.
   - Momentum-rangering: 6-måneders afkast, seneste måned udeladt
     ("skip-month"-momentum — akademisk standardkonstruktion).
   - De 5 højest rangerede (der består trendfilteret) udgør målporteføljen,
     ligevægtet (20% hver). Findes færre end 5 kandidater, forbliver resten
     kontant — agenten tvinger IKKE aktier ind i porteføljen i en nedtrend.
3. **Hver ~5 handelsdage (ugentligt)**: stop-loss-tjek — en position lukkes
   hvis den er faldet 15% fra indgangskursen. Provenuet forbliver kontant
   til næste rebalancering.
4. **Omkostninger**: 0,10% pr. handel (min. 29 i lokal valuta) trækkes fra —
   juster i `config.py` til Nordnets faktiske kurtagesatser.

Alle parametre (kapital, antal positioner, lookback-vinduer, stop-loss,
omkostninger) justeres i `config.py` uden at røre strategilogikken.

## Kandidat-screener (TA + analytiker + popularitet)

Et supplerende værktøj, adskilt fra backtesten: en rangeret liste over hvilke
aktier i universet der ser "modne" ud til køb LIGE NU, baseret på teknisk
analyse, analytiker-konsensus og popularitet/sentiment. Output er
`output/screener.html` (samme visuelle stil som backtest-rapporten).

**Vigtigt at forstå:** dette er IKKE en backtest og IKKE en forudsigelse —
det er et øjebliksbillede bygget af gennemsigtige, regelbaserede signaler.
Analytiker-kursmål og social sentiment tager jævnligt fejl. Brug det som
input til egen research, ikke som en købsanbefaling.

**Kør:**
```
python run_screener.py
```
eller i Colab, i en ny celle:
```python
!python run_screener.py
```
```python
from IPython.display import HTML, display
display(HTML(open('output/screener.html').read()))
```

**Sådan virker rangeringen (tre trin, holder API-kald nede):**

1. **Teknisk shortlist** (`technicals.py`, gratis — genbruger allerede hentet
   kursdata): for hver aktie beregnes trendfilter (kurs > SMA200 — samme
   regel som backtesten), golden/death cross (SMA50 ift. SMA200),
   52-ugers breakout, RSI-oversolgt-rebound/MACD-momentumskift og
   volumenspike. Kun aktier der består trendfilteret kan blive kandidater;
   de bedste `screener_shortlist_size` (default 20) går videre til trin 2.
2. **Analytiker- og sentimentdata** (`sentiment.py`, kun for shortlisten):
   - *Analytikere* (Yahoo Finance via yfinance): konsensus-kursmål,
     købs-/salgsanbefaling, seneste op-/nedgraderinger.
   - *StockTwits* (gratis, uautoriseret API): andel bullish/bearish-tags på
     seneste opslag. Dækker reelt kun amerikanske tickere/ADR'er — europæiske
     og nordiske hjemmemarkeds-tickere vil typisk vise "ingen data" her, det
     er forventet, ikke en fejl.
   - *Reddit* (kræver egen opsætning, se nedenfor): antal opslag der nævner
     aktien i udvalgte subreddits seneste uge, rangeret relativt til de andre
     kandidater i samme kørsel.
3. **Komposit-score** (`screener.py`): teknisk score og analytiker+sentiment-
   score vægtes sammen (default 50/50 — justér `screener_ta_weight` /
   `screener_sentiment_weight` i `config.py`). Mangler en aktie analytiker-/
   sentimentdata helt, får den en neutral score (50) i stedet for at blive
   straffet for manglende dækning.

**Opsætning af Reddit (valgfrit, gratis, ~2 minutter):**

1. Gå til [reddit.com/prefs/apps](https://www.reddit.com/prefs/apps) på en
   almindelig computer eller telefon, log ind, og opret en ny app —
   vælg type **"script"**. Navn og beskrivelse er ligegyldige; "redirect uri"
   kan sættes til `http://localhost`.
2. Du får et **client ID** (strengen lige under app-navnet) og en
   **secret**.
3. I Colab: klik nøgle-ikonet i venstre sidebjælke ("Secrets") → tilføj to
   secrets ved navn `REDDIT_CLIENT_ID` og `REDDIT_CLIENT_SECRET` med de to
   værdier → husk at slå "Notebook access" til for dem. Sådan undgår du at
   have dine Reddit-nøgler liggende i selve koden/gisten.
4. Kør `!pip install -q praw` i en celle før du kører screeneren.

Uden dette hop screeneren automatisk Reddit-delen over — ingen fejl, bare et
"ikke konfigureret" i rapporten.

**Begrænsninger specifikt for screeneren:**
- StockTwits/Reddit er "best effort": uofficielle eller rate-limitede
  API'er, der kan fejle eller mangle data for enkelte aktier uden at det
  vælter resten af kørslen. Jeg har ikke kunnet teste disse live herfra
  (intet internet i det sandbox-miljø værktøjet er bygget i) — hvis noget
  ser forkert ud eller fejler helt, så send mig fejlbeskeden.
  - "Upside" er enten analytiker-konsensus (når den findes) eller et rent
  teknisk estimat (afstand til 52-ugers højeste) — sidstnævnte er IKKE et
  analytisk skøn over fremtidigt afkast, kun en afstandsmåling.
- Screeneren er et øjebliksbillede af i dag — den er bevidst IKKE en del af
  no-lookahead-backtesten, fordi analytiker-/sentimentdata ikke findes
  pænt tidsstemplet bagud i tid på en måde der kan backtestes korrekt.

## Mine Aktier (mobil-app)

En Streamlit-app (`app.py`) med en enkel, "Værdipapirer"-agtig GUI: du
tilføjer aktier til en watchlist ved at skrive et frit navn (fx "novo") —
appen slår selv den rigtige Yahoo-ticker op (fx NOVO-B.CO) via Yahoo
Finances søgefunktion, og falder tilbage til at bruge det du skrev direkte,
hvis opslaget fejler. Tryk "Analysér watchlist", og få et
kort pr. aktie med kurs, dags-ændring, en mini-graf og en komposit-rating
(0-100) + upside-estimat — genbrug af samme TA + analytiker + sentiment-logik
som kandidat-screeneren, men anvendt på én ticker ad gangen i stedet for et
helt univers. Der er også en "AI Chat"-fane; i denne version svarer den kun
med en fast tekst, fordi en rigtig AI-forbindelse kræver en betalt API-nøgle
— skelettet er der, så vi nemt kan koble en rigtig model på senere, hvis du
vil det.

Sådan får du den som en app på telefonen (gratis, ingen installation):

1. Upload `app.py` til dit GitHub-repo (samme metode som du allerede har
   brugt til `swing_screener_single_cell.py`: "Add file → Upload files").
   Upload også den opdaterede `requirements.txt` (nu med `streamlit` tilføjet)
   på samme måde — den overskriver den gamle, hvis GitHub spørger.
2. Gå til https://share.streamlit.io og log ind med din GitHub-konto.
3. Vælg "New app", vælg dit repo (`zipo70/Investment`), branch `main`, og
   angiv `app.py` som hovedfil. Tryk "Deploy".
4. Du får en fast URL (noget i stil med `https://dit-navn.streamlit.app`).
   Åbn den i Safari på din iPhone, tryk på del-ikonet (firkant med pil op),
   og vælg "Føj til hjemmeskærm". Nu ligger den som et app-ikon du kan åbne
   direkte — uden at skulle gå via Colab eller GitHub.

**Vigtig begrænsning**: watchlisten gemmes i en simpel fil på Streamlits
server. Så længe appen er "vågen" (bruges jævnligt) holder den ved — men
efter lang tids inaktivitet kan Streamlit Community Cloud genstarte appen
"fra bunden" og nulstille watchlisten. Til en midlertidig research-app er
det en fair pris for at være gratis; sig til hvis du på et tidspunkt vil
have en mere robust løsning (fx gemme watchlisten i din GitHub-repo i
stedet).

## Vigtige begrænsninger — læs før du stoler på tallene

- **Valuta ikke modelleret**: porteføljen blander USD/EUR/DKK/SEK/NOK/CHF/GBP-
  aktier og summerer deres lokale procentafkast uden FX-konvertering.
  Nordnets vekslingsgebyr ved handel i fremmed valuta (typisk ~0,25–0,5%) er
  IKKE med. Til reel handel skal dette lægges ind.
- **Overlevelsesbias**: universet er dagens likvide aktier — selskaber der er
  gået konkurs eller er afnoteret i backtest-perioden mangler.
- **Eksekvering til dagens slutkurs** på beslutningsdagen — ingen slippage
  eller næste-dags-udførelse modelleret.
- **Sharpe-ratio** antager 0% risikofri rente.
- Historisk performance er INGEN garanti for fremtidig performance.

## Foreslåede næste skridt

1. Kør backtesten, gennemgå `output/report.html` sammen med mig — vi kan
   justere lookback-vinduer, stop-loss, universe eller vægtningsmetode
   (`config.py: weighting = "equal" | "inverse_vol"`) og genkøre.
1b. Kør kandidat-screeneren (`run_screener.py`) op til hver rebalancering for
   at få en rangeret liste med begrundelser — se afsnittet "Kandidat-screener"
   ovenfor.
2. Når du er tilfreds med backtest-resultaterne: byg en simuleret
   paper-trading-loop, der "handler" fremadrettet på nye data uden rigtige
   penge, og følg den i praksis over noget tid (jo længere jo bedre — helst
   flere kvartaler).
3. Kun hvis den simulerede performance over tid ser robust ud: overvej
   manuel eksekvering af agentens forslag på Nordnet — dvs. AGENTEN
   FORESLÅR, DU TRYKKER KØB/SÆLG. Fuldautomatisk ordreafgivelse mod en
   rigtig konto er bevidst uden for scope her.

## Filoversigt

| Fil | Ansvar |
|---|---|
| `universe.py` | Aktieunivers pr. region + benchmark |
| `config.py` | Alle strategi-/backtest-parametre |
| `data_fetch.py` | Henter og cacher kursdata via yfinance |
| `strategy.py` | Trend/momentum-signal og positionsvægte |
| `backtest.py` | Porteføljesimulering (rebalancering, stop-loss, omkostninger) |
| `metrics.py` | CAGR, max drawdown, Sharpe, kvartalsafkast, handelsstatistik |
| `report.py` | Genererer `output/report.html` |
| `run_backtest.py` | Kør backtesten |
| `technicals.py` | Tekniske triggere til screeneren (golden cross, breakout, RSI/MACD, volumen) |
| `sentiment.py` | Analytiker-, StockTwits- og Reddit-data til screeneren |
| `screener.py` | Kandidat-rangering (TA + analytiker + sentiment) |
| `screener_report.py` | Genererer `output/screener.html` |
| `run_screener.py` | Kør kandidat-screeneren |
| `app.py` | "Mine Aktier" — Streamlit-GUI/mobil-app (watchlist + rating) |

Kun til eget analysebrug — ikke finansiel rådgivning.
